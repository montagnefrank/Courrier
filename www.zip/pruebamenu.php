<?php
?>
<div class="beousp marginBelow" data-anchor="usp" data-theme="" data-bgimg="/~/media/product_pages/h5/usp/h5_vapour_usp.jpg" data-bgimgmobile="/~/media/product_pages/h5/usp/h5_vapour_usp_m.jpg" style="height: 600px; background-color: rgb(40, 40, 40);"><div class="bg"><img class="bgImg" src="/~/media/product_pages/h5/usp/h5_vapour_usp.jpg" style="width: 1283px; margin-left: 0px; height: 731px; margin-top: -65px; opacity: 1;"><img class="bgImg" src="/~/media/product_pages/h5/usp/h5_usp_3.jpg" style="width: 1283px; height: 808px; margin-left: 0px; margin-top: -104px; opacity: 0;"><div class="playBtn" style="visibility: hidden; opacity: 0; transform: matrix(0.9, 0, 0, 0.9, 0, 0); z-index: 1;"><canvas width="84" height="96" class="playIcon" style="width: 42px; height: 48px; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"></canvas></div></div>
    
            <div class="block" data-theme="0" data-bg="#b0b2b2" data-bgimg="" data-bgimgmobile="" data-yt="" data-mobilethumbnail="" style="visibility: visible; width: 257px; transform: matrix(1, 0, 0, 1, 0, 0);"><div class="overlay" style="background-color: rgb(0, 0, 0); opacity: 0;"></div>
                <!-- Front content -->
                <div class="label" style="margin-top: 465px; transform-origin: 0px 0px 0px; transform: matrix(1, 0, 0, 1, 30, 0); opacity: 1;">Comfort</div>
                <!-- same text as "toptext" when open!!! -->
                <div class="front" style="transform: matrix(1, 0, 0, 1, 0, 0); visibility: inherit; opacity: 1;">
                    <h1>An easy fit</h1>
                    <p style="opacity: 0;">Designed to fit snugly in your ear, Beoplay H5 come with a choice of ear tips</p>
                    <!-- same text as "subtitletext" when open!!! -->
                </div>
                <!--  Open block content  -->
                <div class="text " style="opacity: 0;">
                    <!-- Small title -->
                    <div class="toptext">Comfort</div>
                    <!-- Large title -->
                    <div class="titletext">An easy fit</div>
                    <!-- Medium title -->
                    <div class="subtitletext">Designed to fit snugly in your ear, Beoplay H5 come with a choice of ear tips</div>
                    <!-- Body -->
                    <div class="bodytext">including Comply™ Sport that have a membrane to prevent moisture interfering with the electronics. These rugged and breathable tips create a near perfect, protective grip in the ear canal that is ideal for exercise or life on the go. And for relaxing with your favourite tunes, four pairs of silicone tips provide a relaxed, comfortable fit.</div>
                </div>
                
                
                <!-- Foreground element (if any) -->
                <div class="foreground" data-yt="" data-thumbnail="/~/media/product_pages/h5/usp/h5_eartips.png" style="height: 0px; opacity: 0;"><img class="thumbnail" src="/~/media/product_pages/h5/usp/h5_eartips.png" style="visibility: inherit; opacity: 1;"></div>
                

            <div class="roundBtn" style="transform: matrix(1, 0, 0, 1, -22, 0); opacity: 1; display: block;"><div class="bg" style="transform-origin: 21px 21px 0px; transform: matrix(0, 0, 0, 0, 0, 0);"></div><div class="cross"><div class="a"></div><div class="b"></div></div><div class="readmore" style="opacity: 0;">Read More</div></div></div>
        
            <div class="block" data-theme="0" data-bg="#282828" data-bgimg="/~/media/product_pages/h5/usp/h5_usp_3.jpg" data-bgimgmobile="" data-yt="8xpMwXpg2vI" data-mobilethumbnail="/~/media/product_pages/h5/usp/h5_usp_3.jpg" style="visibility: visible; width: 257px; transform: matrix(1, 0, 0, 1, 256.6, 0);"><div class="overlay" style="background-color: rgb(0, 0, 0); opacity: 0;"></div>
                <!-- Front content -->
                <div class="label" style="margin-top: 465px; transform-origin: 0px 0px 0px; transform: matrix(1, 0, 0, 1, 30, 0); opacity: 1;">Durability</div>
                <!-- same text as "toptext" when open!!! -->
                <div class="front" style="transform: matrix(1, 0, 0, 1, 0, 0); visibility: inherit; opacity: 1;">
                    <h1>Take them out and about</h1>
                    <p style="opacity: 0;">Splash and dust resistant, Beoplay H5 are made for music and calls on the move.</p>
                    <!-- same text as "subtitletext" when open!!! -->
                </div>
                <!--  Open block content  -->
                <div class="text " style="opacity: 0;">
                    <!-- Small title -->
                    <div class="toptext">Durability</div>
                    <!-- Large title -->
                    <div class="titletext">Take them out and about</div>
                    <!-- Medium title -->
                    <div class="subtitletext">Splash and dust resistant, Beoplay H5 are made for music and calls on the move.</div>
                    <!-- Body -->
                    <div class="bodytext">The housing of the earphones is crafted out of textured rubber and polymer, designed to resist sweat and moisture as well as wear and tear.</div>
                </div>
                
                

            <div class="roundBtn" style="transform: matrix(1, 0, 0, 1, -22, 0); opacity: 1; display: block;"><div class="bg" style="transform-origin: 21px 21px 0px; transform: matrix(0, 0, 0, 0, 0, 0);"></div><div class="cross"><div class="a"></div><div class="b"></div></div><div class="readmore" style="opacity: 0;">Read More</div></div></div>
        
            <div class="block" data-theme="0" data-bg="" data-bgimg="/~/media/product_pages/h5/usp/h5_usb_4.jpg" data-bgimgmobile="/~/media/product_pages/h5/usp/mobile/h5_usp_4_m.png" data-yt="" data-mobilethumbnail="/~/media/product_pages/h5/usp/h5_usb_4.jpg" style="visibility: visible; width: 257px; transform: matrix(1, 0, 0, 1, 513.2, 0);"><div class="overlay" style="background-color: rgb(0, 0, 0); opacity: 0;"></div>
                <!-- Front content -->
                <div class="label" style="margin-top: 465px; transform-origin: 0px 0px 0px; transform: matrix(1, 0, 0, 1, 30, 0); opacity: 1;">Calls</div>
                <!-- same text as "toptext" when open!!! -->
                <div class="front" style="transform: matrix(1, 0, 0, 1, 0, 0); visibility: inherit; opacity: 1;">
                    <h1>Talk, listen, activate</h1>
                    <p style="opacity: 0;">Take calls, listen to music or use voice activation</p>
                    <!-- same text as "subtitletext" when open!!! -->
                </div>
                <!--  Open block content  -->
                <div class="text " style="opacity: 0;">
                    <!-- Small title -->
                    <div class="toptext">Calls</div>
                    <!-- Large title -->
                    <div class="titletext">Talk, listen, activate</div>
                    <!-- Medium title -->
                    <div class="subtitletext">Take calls, listen to music or use voice activation</div>
                    <!-- Body -->
                    <div class="bodytext">Take calls, listen to music or use voice activation – all easily on the intuitive Beoplay H5 thanks to a convenient remote. And Bluetooth 4.2 with aptX and AAC codecs ensures no compromise on <a href="https://www.beoplay.com/landingpages/articles/signaturesound" target="_blank">sound quality</a>.</div>
                </div>
                
                

            <div class="roundBtn" style="transform: matrix(1, 0, 0, 1, -22, 0); opacity: 1; display: block;"><div class="bg" style="transform-origin: 21px 21px 0px; transform: matrix(0, 0, 0, 0, 0, 0);"></div><div class="cross"><div class="a"></div><div class="b"></div></div><div class="readmore" style="opacity: 0;">Read More</div></div></div>
        
            <div class="block" data-theme="0" data-bg="" data-bgimg="/~/media/product_pages/h5/usp/h5_usb_5.jpg" data-bgimgmobile="/~/media/product_pages/h5/usp/mobile/h5_usp_5_m.png" data-yt="" data-mobilethumbnail="/~/media/product_pages/h5/usp/h5_usb_5.jpg" style="visibility: visible; width: 257px; transform: matrix(1, 0, 0, 1, 769.8, 0);"><div class="overlay" style="background-color: rgb(0, 0, 0); opacity: 0;"></div>
                <!-- Front content -->
                <div class="label" style="margin-top: 465px; transform-origin: 0px 0px 0px; transform: matrix(1, 0, 0, 1, 30, 0); opacity: 1;">Materials</div>
                <!-- same text as "toptext" when open!!! -->
                <div class="front" style="visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                    <h1>Durable, strong</h1>
                    <p style="opacity: 0;">The cord on Beoplay H5 connecting the earphones is encased in braided textile</p>
                    <!-- same text as "subtitletext" when open!!! -->
                </div>
                <!--  Open block content  -->
                <div class="text " style="opacity: 0;">
                    <!-- Small title -->
                    <div class="toptext">Materials</div>
                    <!-- Large title -->
                    <div class="titletext">Durable, strong</div>
                    <!-- Medium title -->
                    <div class="subtitletext">The cord on Beoplay H5 connecting the earphones is encased in braided textile</div>
                    <!-- Body -->
                    <div class="bodytext">Inspired by the materials used for making sneakers, the cord on Beoplay H5 connecting the earphones is encased in braided textile – making it durable, comfortable and easy to clean.</div>
                </div>
                
                

            <div class="roundBtn" style="opacity: 1; transform: matrix(1, 0, 0, 1, -22, 0); display: block;"><div class="bg" style="transform-origin: 21px 21px 0px; transform: matrix(0, 0, 0, 0, 0, 0);"></div><div class="cross"><div class="a"></div><div class="b"></div></div><div class="readmore" style="opacity: 0;">Read More</div></div></div>
        
            <div class="block" data-theme="0" data-bg="#526546" data-bgimg="" data-bgimgmobile="" data-yt="" data-mobilethumbnail="" style="visibility: visible; width: 257px; transform: matrix(1, 0, 0, 1, 1026.4, 0);"><div class="overlay" style="background-color: rgb(0, 0, 0); opacity: 0;"></div>
                <!-- Front content -->
                <div class="label" style="margin-top: 465px; transform-origin: 0px 0px 0px; transform: matrix(1, 0, 0, 1, 30, 0); opacity: 1;">Beoplay App</div>
                <!-- same text as "toptext" when open!!! -->
                <div class="front" style="visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                    <h1>Integrated experience</h1>
                    <p style="opacity: 0;">Beoplay H5 seamlessly delivers a best-in-class sound experience whatever you are doing.</p>
                    <!-- same text as "subtitletext" when open!!! -->
                </div>
                <!--  Open block content  -->
                <div class="text " style="opacity: 0;">
                    <!-- Small title -->
                    <div class="toptext">Beoplay App</div>
                    <!-- Large title -->
                    <div class="titletext">Integrated experience</div>
                    <!-- Medium title -->
                    <div class="subtitletext">Beoplay H5 seamlessly delivers a best-in-class sound experience whatever you are doing.</div>
                    <!-- Body -->
                    <div class="bodytext">Just choose one of the preset profiles, such as working out, commuting or relaxing, from the Beoplay App. You can also choose to tweek the tonality using the intuitive B&amp;O PLAY ToneTouch interface. It’s even possible to customize your own presets on your iPhone and quickly access them from your Apple Watch when you’re on the move.</div>
                </div>
                
                
                <!-- Foreground element (if any) -->
                <div class="foreground" data-yt="aS9HGu0b9RM" data-thumbnail="/~/media/product_pages/h5/usp/h5_usp_1.jpg" style="height: 0px; opacity: 0;"><div class="playBtn" style="visibility: hidden; opacity: 0; transform: matrix(0.9, 0, 0, 0.9, 0, 0);"><canvas width="84" height="96" class="playIcon" style="width: 42px; height: 48px;"></canvas></div></div>
                

            <div class="roundBtn" style="opacity: 1; transform: matrix(1, 0, 0, 1, -22, 0); display: block;"><div class="bg" style="transform-origin: 21px 21px 0px; transform: matrix(0, 0, 0, 0, 0, 0);"></div><div class="cross"><div class="a"></div><div class="b"></div></div><div class="readmore" style="opacity: 0;">Read More</div></div></div>
        
<div class="roundBtn rotated" style="opacity: 0; display: block; transform: matrix(1, 0, 0, 1, -162, 0);"><div class="bg" style="transform-origin: 21px 21px 0px; transform: matrix(0, 0, 0, 0, 0, 0);"></div><div class="cross" style="transform: matrix(0.7071, 0.7071, -0.7071, 0.7071, 0, 0);"><div class="a"></div><div class="b"></div></div></div></div>


                                                       