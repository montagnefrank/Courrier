<script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>        
<script type='text/javascript' src='js/plugins/jquery-validation/jquery.validate.min.js'></script>
<script type='text/javascript' src='js/plugins/jquery-validation/additional-methods.js'></script>
<script type='text/javascript' src='js/plugins/jquery-validation/additional-methods.min.js'></script>
